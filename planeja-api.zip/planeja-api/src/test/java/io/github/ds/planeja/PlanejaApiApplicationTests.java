package io.github.ds.planeja;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PlanejaApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
